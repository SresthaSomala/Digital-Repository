-- Create the database
CREATE DATABASE IF NOT EXISTS repository;

USE repository;

CREATE TABLE theses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  year INT NOT NULL,
  topic VARCHAR(255) NOT NULL,
  keywords TEXT,
  email VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  submission_id INT NOT NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (submission_id) REFERENCES theses(id) ON DELETE CASCADE
);

CREATE TABLE statistics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  thesis_id INT NOT NULL,
  views_count INT DEFAULT 0,
  downloads_count INT DEFAULT 0,
  FOREIGN KEY (thesis_id) REFERENCES theses(id) ON DELETE CASCADE
);

