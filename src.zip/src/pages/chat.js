import Chat from '../app/Chat/page';

const ChatPage = () => {
  return <Chat />;
};

export default ChatPage;
