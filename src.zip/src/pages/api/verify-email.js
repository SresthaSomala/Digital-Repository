import db from '../../lib/db';

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ message: 'Method not allowed' });
    }

    const { email } = req.body;

    // Basic validation
    if (!email) {
        return res.status(400).json({ message: 'Email is required' });
    }

    const query = 'SELECT * FROM users WHERE username = ?';
    
    try {
        const results = await db.query(query, [email]);
        
        if (results.length === 0) {
            return res.status(404).json({ message: 'Email not found' });
        }

        // Email exists
        return res.status(200).json({ message: 'Email verified', exists: true });
    } catch (error) {
        console.error('Database error:', error);
        return res.status(500).json({ message: 'Database error occurred' });
    }
}