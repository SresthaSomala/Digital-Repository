// src/pages/api/upload-file.js
import * as formidable from 'formidable';
import fs from 'fs';
import path from 'path';
import db from '../../lib/db';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const uploadDir = path.join(process.cwd(), '/uploads');
  fs.mkdirSync(uploadDir, { recursive: true });

  const form = new formidable.IncomingForm();
  form.uploadDir = uploadDir;
  form.keepExtensions = true;

  form.on('fileBegin', (name, file) => {
    const fileName = file.originalFilename || file.newFilename;
    file.filepath = path.join(uploadDir, fileName);
    file.fileName = fileName;
  });
  

  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(500).json({ error: 'File upload failed' });
    }

    // Extract single values from fields
    const title = Array.isArray(fields.title) ? fields.title[0] : fields.title;
    const author = Array.isArray(fields.author) ? fields.author[0] : fields.author;
    const year = Array.isArray(fields.year) ? parseInt(fields.year[0], 10) : parseInt(fields.year, 10);
    const topic = Array.isArray(fields.topic) ? fields.topic[0] : fields.topic;
    const keywords = Array.isArray(fields.keywords) ? fields.keywords[0] : fields.keywords;
    const email = Array.isArray(fields.email) ? fields.email[0] : fields.email;

    const fileName = files.file[0].originalFilename;
    const filePath = `/uploads/${fileName}`;

    try {
      // Insert metadata and file path into the `theses` table
      const [result] = await db.execute(
        `INSERT INTO theses (title, author, year, topic, keywords, email, file_path) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [title, author, year, topic, keywords, email, filePath]
      );

      const trackingId = result.insertId;
      res.status(200).json({ message: 'Thesis uploaded successfully', trackingId });
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).json({ error: 'Database error' });
    }
  });
}
