// src/pages/api/get-submissions.js
import db from '../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const [rows] = await db.execute('SELECT id, title, author, year, topic, keywords, email, file_path, submission_date FROM theses ORDER BY submission_date DESC');
    res.status(200).json(rows);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Database error' });
  }
}
