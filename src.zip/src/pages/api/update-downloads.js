import db from '../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { thesisId } = req.body;
  if (!thesisId) {
    return res.status(400).json({ error: 'Thesis ID is required' });
  }

  try {
    await db.execute(
      `INSERT INTO statistics (thesis_id, views_count, downloads_count)
       VALUES (?, 0, 1)
       ON DUPLICATE KEY UPDATE downloads_count = downloads_count + 1`,
      [thesisId]
    );

    res.status(200).json({ message: 'Download count updated' });
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Failed to update download count' });
  }
}
