import db from '../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { id } = req.query;
  if (!id) {
    return res.status(400).json({ error: 'Submission ID is required' });
  }

  // Set headers to prevent caching
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('Surrogate-Control', 'no-store');

  try {
    // Fetch submission details from the `theses` table
    const [submissionResult] = await db.execute(
      `SELECT * FROM theses WHERE id = ?`,
      [id]
    );

    if (submissionResult.length === 0) {
      return res.status(404).json({ error: 'Submission not found' });
    }

    const submission = submissionResult[0];

    // Fetch comments related to the submission
    const [commentsResult] = await db.execute(
      `SELECT id, comment FROM comments WHERE submission_id = ? ORDER BY created_at ASC`,
      [id]
    );

    submission.comments = commentsResult;

    res.status(200).json(submission);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Failed to fetch submission details' });
  }
}
