// src/pages/api/register.js
import connection from '../../lib/db';
import jwt from 'jsonwebtoken';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Only POST requests are allowed' });
  }

  const { username, password, firstName, lastName } = req.body;

  if (!username || !password || !firstName || !lastName) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const [existingUser] = await connection.execute('SELECT * FROM users WHERE username = ?', [username]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'Username already exists' });
    }

    // Insert new user into the database with plain text password
    const [result] = await connection.execute(
      'INSERT INTO users (firstname, lastname, username, password) VALUES (?, ?, ?, ?)',
      [firstName, lastName, username, password]
    );

    // Generate JWT Token
    const token = jwt.sign({ userId: result.insertId }, process.env.JWT_SECRET_KEY, { expiresIn: '1h' });

    res.setHeader(
      'Set-Cookie',
      `authToken=${token}; HttpOnly; Path=/; Max-Age=3600; Secure; SameSite=Strict`  // Added SameSite for CSRF protection
    );

    return res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Register API Error:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
}
