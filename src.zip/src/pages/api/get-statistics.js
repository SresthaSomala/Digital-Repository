// SELECT thesis_id, views_count, downloads_count FROM statistics ORDER BY views_count DESC LIMIT 10

import db from '../../lib/db';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      // Modify the SQL query to fetch the required PDF statistics with thesis titles
      const results = await db.query(`
        SELECT thesis_id, views_count, downloads_count FROM statistics ORDER BY views_count DESC LIMIT 10
      `);
      
      // Extract the results (adjust based on your database library)
      const pdfs = Array.isArray(results[0]) ? results[0] : results;
      console.log('Fetched PDF statiistics:', pdfs);



      res.status(200).json(pdfs);
    } catch (error) {
      console.error('Failed to fetch PDF statistics:', error);
      res.status(500).json({ 
        message: 'Failed to fetch PDF statistics',
        error: error.message 
      });
    }
  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}