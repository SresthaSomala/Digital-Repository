import connection from '../../lib/db.js';  // Use default import

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Only POST requests are allowed' });
  }

  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try {
    const connections = await connection;  // Since connection is already initialized, no need to call it
    const [rows] = await connections.execute('SELECT * FROM users WHERE username = ?', [email]);

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = rows[0];

    // Compare the input password with the stored hashed password
    if (user.password !== password) {
      return res.status(401).json({ message: 'Wrong calculation' });
    }

    // Generate JWT Token
    const jwt = require('jsonwebtoken');
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET_KEY, { expiresIn: '1h' });

    res.setHeader('Set-Cookie', `authToken=${token}; HttpOnly; Path=/; Max-Age=3600; Secure=${process.env.NODE_ENV === 'production'}`);

    return res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error('Login API Error:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
}
