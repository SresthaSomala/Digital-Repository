import db from '../../lib/db';

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ message: 'Method not allowed' });
    }

    const { email, password } = req.body;

    // Basic validation
    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required' });
    }

    try {
        // Update the user's password in the database
        const query = 'UPDATE users SET password = ? WHERE username = ?';
        const result = await db.query(query, [password, email]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        return res.status(200).json({ message: 'Password updated successfully' });
    } catch (error) {
        console.error('Database error:', error);
        return res.status(500).json({ message: 'Error updating password' });
    }
}