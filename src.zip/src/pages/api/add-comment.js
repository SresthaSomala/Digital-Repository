import db from '../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { submissionId, comment } = req.body;

  if (!submissionId || !comment) {
    return res.status(400).json({ error: 'Submission ID and comment are required' });
  }

  try {
    // Insert the comment into the comments table
    const [result] = await db.execute(
      `INSERT INTO comments (submission_id, comment) VALUES (?, ?)`,
      [submissionId, comment]
    );

    res.status(200).json({ message: 'Comment added successfully', comment: { id: result.insertId, comment } });
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Failed to add comment' });
  }
}
