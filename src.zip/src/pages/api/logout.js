export default async function handler(req, res) {
    if (req.method !== 'POST') {
      return res.status(405).json({ message: 'Only POST requests are allowed' });
    }
  
    try {
      // Clear the auth token from the cookies
      res.setHeader('Set-Cookie', 'authToken=; HttpOnly; Path=/; Max-Age=0; Secure=true');
  
      return res.status(200).json({ message: 'Logout successful' });
    } catch (error) {
      console.error('Logout API Error:', error);
      return res.status(500).json({ message: 'Internal server error' });
    }
  }
  