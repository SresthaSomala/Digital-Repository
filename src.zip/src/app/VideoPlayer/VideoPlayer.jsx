"use client";

import React, { useRef } from "react";
import "./VideoPlayer.css";

const VideoPlayer = ({ playState, setPlayState }) => {
  // Reference to the video element
  const videoRef = useRef(null);

  // Function to toggle playback state
  const togglePlayState = () => {
    if (playState) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setPlayState(!playState);
  };

  return (
    <div className={`video-player ${playState ? "" : "hide"}`}>
      <video ref={videoRef} loop muted controls>
        <source src="/assets/Hero_Vid.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <button onClick={togglePlayState} aria-label={playState ? "Pause Video" : "Play Video"}>
        {playState ? "Pause" : "Play"}
      </button>
    </div>
  );
};

export default VideoPlayer;
