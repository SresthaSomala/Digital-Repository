"use client";

import React, { useRef, useEffect } from 'react';
import './Review.css';

const Review = () => {
    const slider = useRef();
    let tx = 0;  // This variable tracks the current translateX percentage
    let autoScroll;

    const numSlides = 4;  // Adjust this based on the number of slides you have
    const slideWidth = 25;  // Each slide moves 25% of the slider width

    const slideForward = () => {
        tx -= slideWidth;
        if (tx < -slideWidth * (numSlides - 1)) {
            tx = 0;  // Reset to start if it's the last slide
        }
        slider.current.style.transform = `translateX(${tx}%)`;
    };

    const slideBackward = () => {
        if (tx === 0) {
            tx = -slideWidth * (numSlides - 1);  // Set to the last slide if it's the first slide
        } else {
            tx += slideWidth;
        }
        slider.current.style.transform = `translateX(${tx}%)`;
    };

    useEffect(() => {
        autoScroll = setInterval(slideForward, 3000);  // Auto-scroll every 3 seconds
        return () => clearInterval(autoScroll);  // Cleanup on component unmount
    }, []);

    return (
        <div className='Review'>
            <img src="/assets/next-icon.png" alt="Next slide" className='next-btn' onClick={slideForward} />
            <img src="/assets/back-icon.png" alt="Previous slide" className='back-btn' onClick={slideBackward} />
            <div className="slider">
                <ul ref={slider}>
                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src="/assets/user-1.png" alt="Angela Rao" />
                                <div>
                                    <h3>Angela Rao</h3>
                                    <span>UTA, USA</span>
                                </div>
                            </div>
                            <p>The website is clean and concise and I can easily find the thesis articles from the search button</p>
                        </div>
                    </li>
                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src="/assets/user-2.png" alt="Vikram Rathod" />
                                <div>
                                    <h3>Vikram Rathod</h3>
                                    <span>UTA, USA</span>
                                </div>
                            </div>
                            <p>The website is clean and concise and I can easily find the thesis articles from the search button</p>
                        </div>
                    </li>
                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src="/assets/user-3.png" alt="Jimmy Shergill" />
                                <div>
                                    <h3>Jimmy Shergill</h3>
                                    <span>UTA, USA</span>
                                </div>
                            </div>
                            <p>The website is clean and concise and I can easily find the thesis articles from the search button</p>
                        </div>
                    </li>
                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src="/assets/user-4.png" alt="Manoj Vajpayee" />
                                <div>
                                    <h3>Manoj Vajpayee</h3>
                                    <span>UTA, USA</span>
                                </div>
                            </div>
                            <p>The website is clean and concise and I can easily find the thesis articles from the search button</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    );
};

export default Review;
