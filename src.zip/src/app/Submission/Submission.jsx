"use client";

import React, { useState } from "react";
import "./Submission.css";

const ThesisSubmissionPage = () => {
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [file, setFile] = useState(null);
  const [email, setEmail] = useState("");
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [year, setYear] = useState("");
  const [topic, setTopic] = useState("");
  const [keywords, setKeywords] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const togglePopup = () => {
    setIsPopupVisible((prevState) => !prevState);
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
  
    const formData = new FormData();
    formData.append("file", file);
    formData.append("email", email);
    formData.append("title", title);
    formData.append("author", author);
    formData.append("year", year);
    formData.append("topic", topic);
    formData.append("keywords", keywords);
  
    try {
      const response = await fetch("/api/upload-file", {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
  
      if (response.ok) {
        setSubmitted(true);
        alert(`Submission successful! Tracking ID: ${data.trackingId}`);
        setIsPopupVisible(false);
        window.location.reload();
      } else {
        alert("Failed to upload thesis. Please try again.");
      }
    } catch (error) {
      console.error("File upload error", error);
      alert("An error occurred. Please try again.");
    }
  };
  

  return (
    <div className="thesis-submission-page">
      <h2>Thesis Submission</h2>
      <div className="section">
        <h3>Submission Guidelines</h3>
        <p>Please read the following guidelines carefully before submitting your thesis.</p>
        <ul>
          <li>Ensure your thesis follows the provided template.</li>
          <li>Only PDF files are accepted.</li>
          <li>Max file size is 50MB.</li>
        </ul>
      </div>

      <div className="section">
        <h3>Template</h3>
        <div className="button-container">
          <a href="/THESIS.pdf" target="_blank" rel="noopener noreferrer" className="template">
            View Template
          </a>
          <button onClick={togglePopup}>Submit your Thesis</button>
        </div>
      </div>
      <div className={`popup-form ${isPopupVisible ? "show" : ""}`}>
        <div className="popup-content">
          <h3 className="thesis_center">Thesis Submission Form</h3>
          <form onSubmit={handleSubmit}>
            <div>
              <label>Title:</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Author:</label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Year:</label>
              <input
                type="number"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Topic:</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Keywords:</label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Email:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Upload Thesis:</label>
              <input type="file" accept=".pdf" onChange={handleFileChange} required />
            </div>
            <div className="popup-buttons">
              <button type="submit">Submit Thesis</button>
              <button type="button" onClick={togglePopup}>
                Close
              </button>
            </div>
          </form>
          {submitted && (
            <p>Submission received! Tracking ID: {Math.floor(Math.random() * 100000)}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ThesisSubmissionPage;
