"use client";

import React, { useState, useEffect } from 'react';
import './Repository.css';

const PdfCard = ({ thesis }) => {
  return (
      <div className="pdf-card">
          <div className="pdf-card-body">
              <h5 className="pdf-title">{thesis.title}</h5>
              <p className="pdf-author">Author: {thesis.author}</p>
              <p className="pdf-year">Year: {thesis.year}</p>
              <p className="pdf-topic">Topic: {thesis.topic}</p>
              <a
                  href={`http://localhost:5000/${thesis.file_path}`} // Prefix with server's URL
                  target="_blank"
                  rel="noopener noreferrer"
              >
                  Download 
              </a>
          </div>
      </div>
  );
};


const PdfGallery = () => {
    const [theses, setTheses] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetch('http://localhost:5000/api/theses') // Adjust URL if needed
            .then(response => response.json())
            .then(data => setTheses(data))
            .catch(error => console.error('Error fetching theses data:', error));
    }, []);

    const handleSearch = event => {
        setSearchTerm(event.target.value);
    };

    const filteredTheses = theses.filter(thesis =>
        thesis.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        thesis.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        thesis.year.toString().includes(searchTerm) ||
        thesis.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
        thesis.keywords.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <input className="search-bar"
                type="text"
                placeholder="Search by title, author, year, topic, or keywords..."
                value={searchTerm}
                onChange={handleSearch}
            />
            <div className="pdf-gallery">
                {filteredTheses.map(thesis => <PdfCard key={thesis.id} thesis={thesis} />)}
            </div>
        </div>
    );
};

export default PdfGallery;
