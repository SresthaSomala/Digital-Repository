'use client';

import { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';
import './Chat.css';

let socket;

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const Chat = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [userId, setUserId] = useState(null);
  const chatBoxRef = useRef(null);

  const scrollToBottom = () => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    socket = io();
    const storedUserId = localStorage.getItem('userId') || generateUUID();
    setUserId(storedUserId);

    socket.auth = { userId: storedUserId };
    socket.connect();

    socket.on('message', (data) => {
      setMessages((prevMessages) => [...prevMessages, data]);
      setTimeout(scrollToBottom, 100);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = (e) => {
    e.preventDefault();
    if (message.trim()) {
      socket.emit('message', {
        message,
        userId,
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit'
        })
      });
      setMessage('');
    }
  };

  return (
    <div className="chat-container">
      <h2 className="chat-title"> Welcome to the * Thesis Vault * Chat Room</h2>
      <div className="chat-box" ref={chatBoxRef}>
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`message-container ${msg.user === userId ? 'sent' : 'received'}`}
          >
            <div className={`message-bubble ${msg.user === userId ? 'sent' : 'received'}`}>
              <div className="message-header">
                <span className="user-id">{msg.user === userId ? 'You' : msg.user}</span>
                <span className="timestamp">{msg.time}</span>
              </div>
              <div className="message-text">{msg.message}</div>
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={sendMessage} className="chat-form">
        <input
          type="text"
          placeholder="Type a message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="chat-input"
        />
        <button type="submit" className="send-button">
          Send
        </button>
      </form>
    </div>
  );
};

export default Chat;