"use client";

import React, { useState, useEffect } from 'react';
import Navbar from './navbar/Navbar';
import Hero from './Hero/Hero';
import Programs from './Programs/Programs';
import Title from './Title/Title';
import About from './About/About';
import Team from './Team/Team';
import Review from './Peer Review/Review';
import Contact from './Contact/Contact';
import VideoPlayer from './VideoPlayer/VideoPlayer';
import PdfGallery from './Repository/Repository';
import ThesisSubmissionPage from './Submission/Submission';
import Statistics from './Statistics/Statistics';
import Login from './Login/Login';  // Ensure Login component is imported
import SubmissionsPage from './submissions//page';

const App = () => {
  // Add this useEffect for smooth scrolling
  useEffect(() => {
    // Apply smooth scrolling behavior to html element
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Optional: Clean up when component unmounts
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  const [isAuthenticated, setIsAuthenticated] = useState(false);  // Authentication state
  const [playState, setPlayState] = useState(false);
  const [error, setError] = useState('');

  // Check for authentication in localStorage or cookies when the page loads
  useEffect(() => {
    // Check if the user is authenticated (e.g., if a token or flag exists in localStorage)
    const authToken = localStorage.getItem('authToken');
    if (authToken) {
      setIsAuthenticated(true);
    }
  }, []);



  // Handle login logic
  const handleLogin = async (credentials) => {
    setError(''); // Reset any previous error messages

    // Send the credentials to the backend for authentication
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      const data = await response.json();

      if (response.ok) {
        setIsAuthenticated(true);
        // Save auth token to localStorage or cookies for persistence
        localStorage.setItem('authToken', data.token); // Assuming you return a token
      } else {
        // Handle invalid login
        setError(data.message || 'Invalid login credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError('Something went wrong, please try again later.');
    }
  };

  return (
    <div>
      {isAuthenticated ? (
        <>
          <Navbar />
          <Hero />
          <div className="container">
            <Title subTitle="Our PROGRAM" title="What We Offer" />
            <Programs />
            {/* <Title subTitle="Repository" title="Search for Papers" />
            <PdfGallery pdfs={pdfs} /> */}
            <Title subTitle="Submit Thesis" title="Share your work with our community" />
            <ThesisSubmissionPage />
            <Title subTitle="Thesis Submissions" title="View All Submissions" />
            <SubmissionsPage />
            {/* <a href="/submissions" target="_blank" rel="noopener noreferrer">
              <button>Open Submissions in New Tab</button>
            </a> */} 
            <Title subTitle="Statistics" title="Here are some of the numbers" />
            <Statistics />

            <About setPlayState={setPlayState} />
            <VideoPlayer playState={playState} setPlayState={setPlayState} />
            <Title subTitle="Testimonials" title="What a student says" />
            <Review />
            <Title subTitle="Meet the Team" title="Bunch of Engineers" />
            <Team />
            <Title subTitle="Contact us" title="Get in Touch" />
            <Contact />
          </div>
        </>
      ) : (
        <Login onLogin={handleLogin} error={error} />
      )}
    </div>
  );
};

export default App;