"use client";

import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'next/navigation';
import './SubmissionDetail.css';

const SubmissionDetail = () => {
  const params = useParams();
  const { id } = params;
  const [submission, setSubmission] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const viewIncremented = useRef(false); // useRef to ensure single increment per load

  useEffect(() => {
    const fetchSubmission = async () => {
      if (!id) return;

      try {
        const response = await fetch(`/api/get-submission?id=${id}`);
        if (!response.ok) throw new Error('Failed to fetch submission details');
        const data = await response.json();
        setSubmission(data);
        setComments(data.comments || []);
      } catch (error) {
        console.error("Error fetching submission details:", error);
      }
    };

    fetchSubmission();
  }, [id]);

  useEffect(() => {
    if (!viewIncremented.current) { // Only increment if not already done
      const incrementViews = async () => {
        try {
          await fetch(`/api/update-views`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ thesisId: id }),
          });
          viewIncremented.current = true; // Mark as incremented after successful request
        } catch (error) {
          console.error('Error updating view count:', error);
          setErrorMessage('Failed to increment view count. Please try again.');
        }
      };

      incrementViews();
    }
  }, [id]);

  const handleDownload = async () => {
    console.log('Sending payload:', { thesisId: id }); // Debugging
    try {
      const response = await fetch(`/api/update-downloads`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ thesisId: id }),
      });
  
      if (!response.ok) {
        throw new Error('Failed to increment download count');
      }
    } catch (error) {
      console.error('Error updating download count:', error);
      setErrorMessage('Failed to increment download count. Please try again.');
    }
  };
  
  
  const handleCommentSubmit = async (event) => {
    event.preventDefault();
    if (!newComment.trim()) return;

    try {
      const response = await fetch(`/api/add-comment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ submissionId: id, comment: newComment }),
      });
      const data = await response.json();
      if (response.ok) {
        setComments([...comments, data.comment]);
        setNewComment('');
      } else {
        console.error('Failed to add comment');
        setErrorMessage('Failed to add comment. Please try again.');
      }
    } catch (error) {
      console.error('Error adding comment:', error);
      setErrorMessage('An unexpected error occurred. Please try again.');
    }
  };

  if (!submission) return <p>Loading...</p>;

  return (
    <div className="submission-detail">
      <h2>{submission.title}</h2>
      <p><strong>Author:</strong> {submission.author}</p>
      <p><strong>Year:</strong> {submission.year}</p>
      <p><strong>Topic:</strong> {submission.topic}</p>
      <p><strong>Keywords:</strong> {submission.keywords}</p>
      <p><strong>Email:</strong> {submission.email}</p>
      <p><strong>Submission Date:</strong> {new Date(submission.submission_date).toLocaleString()}</p>
      <a href={submission.file_path} download onClick={handleDownload} className="download-link">
        Download PDF
      </a>

      {errorMessage && <p className="error-message">{errorMessage}</p>}

      <div className="comments-section">
        <h3>Comments</h3>
        {comments.map((comment, index) => (
          <p key={index} className="comment">{comment.comment}</p> 
        ))}
        <form onSubmit={handleCommentSubmit} className="comment-form">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment..."
            required
          />
          <button type="submit">Submit Comment</button>
        </form>
      </div>
    </div>
  );
};

export default SubmissionDetail;
