"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import './Submissions.css';


const SubmissionsPage = () => {
  const [submissions, setSubmissions] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredSubmissions, setFilteredSubmissions] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const submissionsPerPage = 5;

  useEffect(() => {
    const fetchSubmissions = async () => {
      try {
        const response = await fetch('/api/get-submissions');
        if (!response.ok) throw new Error('Failed to fetch submissions');
        const data = await response.json();
        setSubmissions(data);
        setFilteredSubmissions(data);
      } catch (error) {
        console.error("Error fetching submissions:", error);
      }
    };

    fetchSubmissions();
  }, []);

  const handleSearch = (event) => {
    const query = event.target.value.toLowerCase();
    setSearchQuery(query);
    
    const filtered = submissions.filter((submission) =>
      Object.values(submission).some((field) =>
        String(field).toLowerCase().includes(query)
      )
    );

    setFilteredSubmissions(filtered);
    setCurrentPage(1);
  };

  const indexOfLastSubmission = currentPage * submissionsPerPage;
  const indexOfFirstSubmission = indexOfLastSubmission - submissionsPerPage;
  const currentSubmissions = filteredSubmissions.slice(indexOfFirstSubmission, indexOfLastSubmission);
  const totalPages = Math.ceil(filteredSubmissions.length / submissionsPerPage);

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const router = useRouter();

  const handleItemClick = (submissionId) => {
    router.push(`/submissions/${submissionId}`);
  };

  return (
    <div className="submissions-page">
      <input
        type="text"
        placeholder="Search submissions..."
        value={searchQuery}
        onChange={handleSearch}
        className="search-bar"
      />
      <div className="submissions-list">
        {currentSubmissions.map((submission) => (
          <div
            className="submission-card"
            key={submission.id}
            onClick={() => handleItemClick(submission.id)}
          >
            <h3>{submission.title}</h3>
            <p><strong>Author:</strong> {submission.author}</p>
            <p><strong>Year:</strong> {submission.year}</p>
            <p><strong>Topic:</strong> {submission.topic}</p>
            <p><strong>Keywords:</strong> {submission.keywords}</p>
            <p><strong>Email:</strong> {submission.email}</p>
            <p><strong>File path:</strong> {submission.file_path}</p>
            <p><strong>Submission Date:</strong> {new Date(submission.submission_date).toLocaleString()}</p>
            <a href={submission.file_path} download className="download-link">
              View
            </a>
          </div>
        ))}
      </div>
      <div className="pagination">
        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
          <button
            key={page}
            onClick={() => handlePageChange(page)}
            className={page === currentPage ? 'active' : ''}
          >
            {page}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SubmissionsPage;
