import React from 'react';
import './Hero.css';
import { Link as ScrollLink } from 'react-scroll';


const Hero = () => {
  return (
    <section className='hero container' aria-label="Welcome to UTA Thesis Repository">
        <div className="hero-text">
            <h1>Welcome to UTA Thesis Repository</h1>
            <p>Discover, Share, and Advance Academic Excellence. Your gateway to a world of groundbreaking research, innovative ideas, and scholarly achievements. </p>
            <p>Join our growing community of researchers, educators, and knowledge seekers.</p>
            <ScrollLink to="programs" smooth={true} duration={500}>
            <button className="btn" aria-label="Explore more about UTA Thesis Repository">Explore more</button>
            </ScrollLink>

        </div>
       
    </section>
  );
}

export default Hero;
