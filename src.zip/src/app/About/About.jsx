import React from "react";
import "./About.css";

const About = ({ setPlayState }) => {
  return (
    <div className="about">
      <div className="about-left">
        <img src="assets/about.png" alt="" className="about-img" />
        <img
          src={"assets/play-icon.png"}
          alt=""
          className="play-icon"
          onClick={() => setPlayState(true)} // Start playing the video
        />
      </div>
      <div className="about-right">
        <h3>About Repository</h3>
        <h2>Nurturing Tomorrow's Leaders Today</h2>
        <p>
          UTA Thesis Repository is a leading academic institution dedicated to promoting scholarly excellence and preparing students for the global job market. Located in Arlington, Texas, our mission is to provide academic resources, support, and opportunities to help students and faculty build their careers.
        </p>
        <p>
          Created by
          <a href="https://www.linkedin.com/in/venkateshaprasad/"> Venkatesha Prasad S,</a>
          <a href="https://www.linkedin.com/in/ganga-thummaluru-bab7aa297/"> Ganga Lakshmi Thummaluru,</a>
          <a href="https://www.linkedin.com/in/jaswanthc-sunkara"> Jaswanth Chowdary Sunkara,</a>
          <a href="https://www.linkedin.com/in/t-praveen-kumar"> Praveen Kumar Thummala</a> and
          <a href="https://www.linkedin.com/in/srestha-somala-790a14184"> Srestha Somala</a>
        </p>
        <p>You can contact us by clicking on the links to our socials below</p>
        <p>+ 987-654-3210</p>
      </div>
    </div>
  );
};

export default About;
