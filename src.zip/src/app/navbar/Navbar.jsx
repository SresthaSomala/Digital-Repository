"use client";

import React, { useEffect, useState } from 'react';
import './Navbar.css';
import { Link as ScrollLink } from 'react-scroll';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faComment, faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';


const Navbar = () => {
  const [sticky, setSticky] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setSticky(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);

    // Cleanup on unmount
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setMenuVisible(prevState => !prevState);
  };

  const handleLogout = async () => {
    try {
      // Clear session or authentication data on the client-side
      sessionStorage.removeItem('userSession');
      localStorage.clear();

      // Send a POST request to the server-side logout API
      const response = await fetch('/api/logout', {
        method: 'POST',
      });

      if (response.ok) {
        // Redirect to the login page or home page
        window.location.href = '/';  // You can adjust the path as needed
      } else {
        console.error('Logout failed');
      }
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  return (
    <nav className={`container ${sticky ? 'dark-nav' : ''}`}>
      <img src="/assets/logo3.png" alt="Logo" className='logo' />
      <ul className={menuVisible ? '' : 'hide-mobile-menu'}>
        <li><ScrollLink to='hero' smooth={true} duration={500}>Home</ScrollLink></li>

        <li><ScrollLink to='thesis-submission-page' offset={-260} smooth={true} duration={500}>Submit Thesis</ScrollLink></li>
        <li><ScrollLink to='statistics' offset={-260} smooth={true} duration={500}>Statistics</ScrollLink></li>
        <li><ScrollLink to='Review' offset={-260} smooth={true} duration={500}>Peer Review</ScrollLink></li>
        <li><ScrollLink to='about' offset={-160} smooth={true} duration={500}>About Us</ScrollLink></li>
       
        <li><ScrollLink to='contact' offset={-160} smooth={true} duration={500}>Contact Us</ScrollLink></li>
        <li>
          <ScrollLink to='submissions-page' offset={-260} smooth={true} duration={500}>
            <FontAwesomeIcon icon={faMagnifyingGlass} />
          </ScrollLink>
        </li>
        <a href="/chat" className="chat-icon" target="_blank" rel="noopener noreferrer">
          <FontAwesomeIcon icon={faComment} />
        </a>

        {/* Logout button */}
        <li>
          <button className='btn logout-btn' onClick={handleLogout}>Logout</button>
        </li>
      </ul>
      <img
        src="/assets/menu-icon.png"
        alt="Menu Icon"
        className='menuIcon'
        onClick={toggleMenu}
        aria-expanded={menuVisible}
      />
    </nav>
  );
};

export default Navbar;
