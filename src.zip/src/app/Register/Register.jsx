import React, { useState } from 'react';
import CryptoJS from 'crypto-js';
import "./Register.css";  // Use the same CSS for styling consistency

const Register = ({ onRegister }) => {
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    username: "",
    password: ""
  });
  const [errorMessage, setErrorMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { firstName, lastName, username, password } = user;

    const encryptedPassword = CryptoJS.SHA256(password).toString();

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ firstName, lastName, username, password: encryptedPassword })
      });

      const data = await response.json();

      if (response.ok) {
        setErrorMessage("");
        alert("Registration successful!");
        onRegister();  // Call to toggle back to the login form or clear fields
      } else {
        setErrorMessage(data.message || "Registration failed");
      }
    } catch (error) {
      setErrorMessage("An error occurred during registration. Please try again.");
    }
  };

  return (
    <div className={`login-box ${errorMessage ? "shake" : ""}`}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit} autoComplete="off">
        <div className="input-group">
          <label htmlFor="firstName">First Name:</label>
          <input
            id="firstName"
            type="text"
            name="firstName"
            value={user.firstName}
            onChange={handleChange}
            required
            autoComplete="given-name"
          />
        </div>

        <div className="input-group">
          <label htmlFor="lastName">Last Name:</label>
          <input
            id="lastName"
            type="text"
            name="lastName"
            value={user.lastName}
            onChange={handleChange}
            required
            autoComplete="family-name"
          />
        </div>

        <div className="input-group">
          <label htmlFor="username">Username:</label>
          <input
            id="username"
            type="text"
            name="username"
            value={user.username}
            onChange={handleChange}
            required
            autoComplete="username"
          />
        </div>

        <div className="input-group">
          <label htmlFor="password">Password:</label>
          <input
            id="password"
            type="password"
            name="password"
            value={user.password}
            onChange={handleChange}
            required
            autoComplete="new-password"
          />
        </div>

        {errorMessage && (
          <div className="error-message">
            {errorMessage}
          </div>
        )}

        <button type="submit">Register</button>

        <div className="register-toggle">
          <span>Already have an account? </span>
          <span
            style={{ color: "blue", cursor: "pointer" }}
            onClick={onRegister}
          >
            Log In
          </span>
        </div>
      </form>
    </div>
  );
};

export default Register;
