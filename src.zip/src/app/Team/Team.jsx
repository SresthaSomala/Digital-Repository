"use client";

import React from 'react';
import Image from 'next/image';
import './Team.css';

const Team = () => {
  return (
    <div className='Team'>
      <div className="gallery"> 
        <a href="https://www.linkedin.com/in/t-praveen-kumar" target="_blank">
          <Image src="/assets/Team1.jpg" alt="Team Member 1" width={200} height={200} />
        </a>
        <a href="https://www.linkedin.com/in/venkateshaprasad/" target="_blank">
          <Image src="/assets/Team2.jpg" alt="Team Member 2" width={200} height={200} />
        </a>
        <a href="https://www.linkedin.com/in/srestha-somala-790a14184" target="_blank">
          <Image src="/assets/Team3.jpg" alt="Team Member 3" width={200} height={200} />
        </a>
        <a href="https://www.linkedin.com/in/jaswanthc-sunkara" target="_blank">
          <Image src="/assets/Team4.jpg" alt="Team Member 4" width={200} height={200} />
        </a>
        <a href="https://www.linkedin.com/in/ganga-thummaluru-bab7aa297/" target="_blank">
          <Image src="/assets/Team5.jpg" alt="Team Member 5" width={200} height={200} />
        </a>
      </div>
    </div>
  );
}

export default Team;
