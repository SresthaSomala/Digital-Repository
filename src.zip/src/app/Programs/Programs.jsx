import React from 'react';
import './Programs.css';

const Programs = () => {
  return (
    <div className="programs">
        <div className="program">
            <img src="/assets/program-1.png" alt=''/>
            <div className='caption'>
              <img src="/assets/program-icon-1.png" alt=''/>
              <p>Centralized Repository</p>
            </div>
        </div>
        <div className="program">
            <img src="/assets/program-2.png" alt=''/>
            <div className='caption'>
              <img src="/assets/program-icon-2.png" alt=''/>
              <p>Community Engagement</p>
            </div>
        </div>
        <div className="program">
            <img src="/assets/program-3.png" alt=''/>
            <div className='caption'>
              <img src="/assets/program-icon-3.png" alt=''/>
              <p>Research Impact</p>
            </div>
        </div>
    </div>
  );
}

export default Programs;
