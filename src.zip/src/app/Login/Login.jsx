import React, { useState } from "react";
import "./Login.css";
import Register from "../Register/Register"; // Import Register component
import ForgotPassword from "../ForgotPassword/ForgotPassword"; // Add this import

const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [errorMessage, setErrorMessage] = useState("");
  const [isShaking, setIsShaking] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false); // State to toggle between Login/Register views
  const [isLoading, setIsLoading] = useState(false); // State for managing loading animation
  const [isForgotPassword, setIsForgotPassword] = useState(false); // Add this state

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true); // Start loading animation
    const { email, password } = credentials;

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      setIsLoading(false); // Stop loading animation

      if (response.ok) {
        setErrorMessage(""); // Clear error if successful
        await onLogin(credentials);
      } else {
        setErrorMessage(data.message || "Invalid email or password");
      }
    } catch (error) {
      setIsLoading(false); // Stop loading animation
      setErrorMessage("An error occurred during login. Please try again.");
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();  // Prevent form submission on Enter key press
    }
  };

  const toggleForm = () => {
    setIsRegistering(!isRegistering); // Toggle between Login and Register forms
  };

  return (
    <div className="login-container">
      <div className="background-image" />
      <div className="overlay" />

      {isRegistering ? (
        <Register onRegister={toggleForm} />
      ) : isForgotPassword ? (
        <ForgotPassword onBack={() => setIsForgotPassword(false)} />
      ) : (
        <div className={`login-box ${isShaking ? "shake" : ""}`}>
          <h2>Login</h2>
          <form onSubmit={handleSubmit} onKeyDown={handleKeyDown} autoComplete="off">
            <div className="input-group">
              <label htmlFor="email">Email:</label>
              <input
                id="email"
                type="email"
                name="email"
                value={credentials.email}
                onChange={handleChange}
                className={errorMessage ? "input-error" : ""}
                required
                autoComplete="email"
              />
            </div>

            <div className="input-group">
              <label htmlFor="password">Password:</label>
              <input
                id="password"
                type="password"
                name="password"
                value={credentials.password}
                onChange={handleChange}
                className={errorMessage ? "input-error" : ""}
                required
                autoComplete="current-password"
              />
            </div>

            {errorMessage && (
              <div className="error-message">
                {errorMessage}
              </div>
            )}

            {isLoading && (
              <div className="loading-spinner">
                Loading...
              </div>
            )}

            <button type="submit">Login</button>

            <div className="forgot-password">
              <span
                style={{ color: "blue", cursor: "pointer" }}
                onClick={() => setIsForgotPassword(true)}
              >
                Forgot Password?
              </span>
            </div>

            <div className="register-toggle">
              <span>Don't have an account? </span>
              <span
                style={{ color: "blue", cursor: "pointer" }}
                onClick={toggleForm}
              >
                Sign Up
              </span>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default Login;
