import React from 'react'
import './Contact.css'

const Contact = () => {''
    const [result, setResult] = React.useState("");

  const onSubmit = async (event) => {
    event.preventDefault();
    setResult("Sending....");
    const formData = new FormData(event.target);

    formData.append("access_key", "97233c20-6f1c-4881-9b5b-381e0466c7b2");

    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (data.success) {
      setResult("Form Submitted Successfully");
      event.target.reset();
    } else {
      console.log("Error", data);
      setResult(data.message);
    }
  };

  return (
    <div className='contact'>
    <div className="contact-col">
        <h3>Send us a message <img src="/assets/msg-icon.png" alt="" /></h3>
        <p>Feel free to reach out through our contact information below.</p>
        <p>Your feedback, questions, suggestions are important to us as we strive to provide exceptional service to our community.</p>
        <ul>
            <li>
                <img src="https://img.icons8.com/color/48/000000/phone.png"/>
                <p>+1 987-654-3210</p>
            </li>
            <li>
                <img src="https://img.icons8.com/color/48/000000/email.png"/>
                <p>rusty@example.com</p>
            </li>
            <li>
                <img src="https://img.icons8.com/color/48/000000/map-marker.png"/>
                <p>123 Main St, City, State, Zip</p>
            </li>
            {/* <li>
                <img src="https://img.icons8.com/color/48/000000/clock.png"/>
                <p>Hours: 9:00 AM - 5:00 PM, Monday - Friday</p>
            </li> */}
            {/* <li>
                <img src="https://img.icons8.com/color/48/000000/chat.png"/>
                <p>Chat: Live Chat</p>
            </li> */}
            {/* <li>
                <img src="https://img.icons8.com/color/48/000000/facebook-circled.png"/>
                <p>Facebook: facebook.com/example</p>
            </li>
            <li>
                <img src="https://img.icons8.com/color/48/000000/twitter.png"/>
                <p>Twitter: twitter.com/example</p>
            </li>
            <li>
                <img src="https://img.icons8.com/color/48/000000/linkedin-circled.png"/>
                <p>LinkedIn: linkedin.com/in/example</p>
            </li> */}
            </ul>
    </div> 
    <div className="contact-col">
        <form onSubmit={onSubmit}>
            <label> Your Name</label>
            <input type="text" name="name" placeholder="Your Name" required/>
            <label> Phone Number</label>
            <input type="text" name="phone" placeholder="Phone Number" required/>
            <label> Email</label>
            <input type="text" name="email" placeholder="Email" required/>
            <label> Write your message here</label>
            <textarea name="message" rows="6" placeholder="Write your message here" required></textarea>
            <button type='submit' className='btn dark-btn'>Submit now</button>
        </form>
        <span>{result}</span>
        </div>    
      
    </div>
  )
}

export default Contact