import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title as ChartTitle, Tooltip, Legend } from 'chart.js';
import './Statistics.css';

ChartJS.register(CategoryScale, LinearScale, BarElement, ChartTitle, Tooltip, Legend);

const Statistics = () => {
  const [pdfs, setPdfs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchPDFStatistics() {
      try {
        const response = await fetch('/api/get-statistics', {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Expires': '0',
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch PDF statistics');
        }

        const data = await response.json();
        setPdfs(data);
        setIsLoading(false);
      } catch (err) {
        setError(err.message);
        setIsLoading(false);
      }
    }

    fetchPDFStatistics();
  }, []);

  // Assuming pdfs contains id, views_count, and downloads_count
  const data = {
    labels: pdfs.map(pdf => `ID: ${pdf.thesis_id}`), // Display id as label
    datasets: [
      {
        label: 'Views',
        data: pdfs.map(pdf => pdf.views_count),
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
      },
      {
        label: 'Downloads',
        data: pdfs.map(pdf => pdf.downloads_count),
        backgroundColor: 'rgba(53, 162, 235, 0.5)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Most Viewed and Downloaded Theses',
      },
    },
  };

  if (isLoading) return <div>Loading statistics...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="statistics">
      <Bar data={data} options={options} />
    </div>
  );
};

export default Statistics;
